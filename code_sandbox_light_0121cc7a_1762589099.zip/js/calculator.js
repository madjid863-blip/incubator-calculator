// حاسبة قدرة مصدر الحرارة للفقاسات
// YalTech Couveuse - www.YalTech-dz.com

document.getElementById('calculatorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    calculateWattage();
});

function calculateWattage() {
    // الحصول على القيم المدخلة
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const height = parseFloat(document.getElementById('height').value);
    const ambientTemp = parseFloat(document.getElementById('ambient').value);
    
    // التحقق من صحة المدخلات
    if (isNaN(length) || isNaN(width) || isNaN(height) || isNaN(ambientTemp)) {
        alert('الرجاء إدخال جميع القيم بشكل صحيح');
        return;
    }
    
    if (length <= 0 || width <= 0 || height <= 0) {
        alert('يجب أن تكون الأبعاد أكبر من صفر');
        return;
    }
    
    // حساب الحجم باللتر (سم³ ÷ 1000)
    const volumeCm3 = length * width * height;
    const volumeLiters = volumeCm3 / 1000;
    
    // درجة الحرارة المستهدفة (متوسط 37.45°م)
    const targetTemp = 37.45;
    
    // فرق درجة الحرارة
    const tempDifference = targetTemp - ambientTemp;
    
    if (tempDifference <= 0) {
        alert('درجة حرارة الغرفة يجب أن تكون أقل من 37.2°م');
        return;
    }
    
    // حساب مساحة السطح الكلية (بالمتر المربع)
    const surfaceAreaCm2 = 2 * (length * width + length * height + width * height);
    const surfaceAreaM2 = surfaceAreaCm2 / 10000;
    
    // معامل فقدان الحرارة (يعتمد على جودة العزل)
    // للفقاسات ذات العزل المتوسط: 3-5 واط/م²/°م
    // نستخدم 4 واط/م²/°م كمتوسط
    const heatLossCoefficient = 4;
    
    // حساب فقدان الحرارة عبر الجدران
    const heatLoss = surfaceAreaM2 * heatLossCoefficient * tempDifference;
    
    // إضافة هامش أمان 20% للتعويض عن:
    // - فتح الأبواب
    // - تبخر الماء
    // - التيارات الهوائية
    const safetyMargin = 1.2;
    
    // القدرة المطلوبة النهائية
    let requiredWattage = heatLoss * safetyMargin;
    
    // تقريب القيمة إلى أقرب 5 واط
    requiredWattage = Math.ceil(requiredWattage / 5) * 5;
    
    // عرض النتائج
    displayResults(requiredWattage, volumeLiters, length, width, height, ambientTemp, tempDifference);
}

function displayResults(wattage, volume, length, width, height, ambientTemp, tempDiff) {
    // تحديث قيمة القدرة
    document.getElementById('wattage').textContent = wattage;
    
    // تحديث الحجم
    document.getElementById('volume').textContent = volume.toFixed(1);
    
    // إنشاء التوصيات
    const recommendations = generateRecommendations(wattage, volume, tempDiff);
    const recommendationsList = document.getElementById('recommendationsList');
    recommendationsList.innerHTML = '';
    
    recommendations.forEach(rec => {
        const li = document.createElement('li');
        li.textContent = rec;
        recommendationsList.appendChild(li);
    });
    
    // إخفاء نموذج الإدخال وعرض النتائج
    document.querySelector('.calculator-card').style.display = 'none';
    document.getElementById('resultCard').classList.remove('hidden');
    document.getElementById('resultCard').classList.add('show');
    
    // التمرير إلى النتائج
    document.getElementById('resultCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function generateRecommendations(wattage, volume, tempDiff) {
    const recommendations = [];
    
    // توصيات حسب القدرة
    if (wattage < 50) {
        recommendations.push('يمكنك استخدام مصباح حراري بقدرة 50 واط');
        recommendations.push('أو استخدام سلك تسخين بقدرة 40-50 واط');
    } else if (wattage < 100) {
        recommendations.push('يفضل استخدام مصباح حراري بقدرة 75-100 واط');
        recommendations.push('أو سلك تسخين بقدرة ' + Math.ceil(wattage / 10) * 10 + ' واط');
    } else if (wattage < 200) {
        recommendations.push('يفضل استخدام عنصر تسخين كهربائي بقدرة ' + Math.ceil(wattage / 25) * 25 + ' واط');
        recommendations.push('أو مصباحين حراريين بقدرة 100 واط لكل منهما');
    } else {
        recommendations.push('يفضل استخدام عنصر تسخين كهربائي قوي بقدرة ' + Math.ceil(wattage / 50) * 50 + ' واط');
        recommendations.push('أو توزيع القدرة على عدة عناصر تسخين');
    }
    
    // توصيات حسب فرق درجة الحرارة
    if (tempDiff > 15) {
        recommendations.push('فرق درجة الحرارة كبير - تأكد من تحسين العزل الحراري');
        recommendations.push('ضع الفقاسة في مكان دافئ لتقليل استهلاك الطاقة');
    }
    
    // توصيات حسب الحجم
    if (volume < 50) {
        recommendations.push('فقاسة صغيرة - تأكد من توزيع الحرارة بشكل متساوي');
    } else if (volume > 500) {
        recommendations.push('فقاسة كبيرة - استخدم أكثر من مصدر حرارة لتوزيع أفضل');
        recommendations.push('ضع مروحة صغيرة لتوزيع الحرارة بالتساوي');
    }
    
    // توصيات عامة
    recommendations.push('استخدم ترموستات دقيق مع حساس حرارة موثوق');
    recommendations.push('راقب درجة الحرارة باستمرار خلال أول 24 ساعة');
    
    return recommendations;
}

function resetCalculator() {
    // إعادة عرض نموذج الإدخال
    document.querySelector('.calculator-card').style.display = 'block';
    document.getElementById('resultCard').classList.remove('show');
    document.getElementById('resultCard').classList.add('hidden');
    
    // التمرير إلى الأعلى
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// إضافة تأثيرات بصرية عند الكتابة
const inputs = document.querySelectorAll('input[type="number"]');
inputs.forEach(input => {
    input.addEventListener('input', function() {
        if (this.value) {
            this.style.borderColor = '#11998e';
        } else {
            this.style.borderColor = '#e0e0e0';
        }
    });
});